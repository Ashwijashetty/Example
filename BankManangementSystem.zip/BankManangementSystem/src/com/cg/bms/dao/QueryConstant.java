package com.cg.bms.dao;

public interface QueryConstant {

	public static final String insertAccount ="insert into account_master values(account_sequence.nextval,?,?,?,?)";
    public static final String selectMaxId="select max(account_no)from account_master";
}
