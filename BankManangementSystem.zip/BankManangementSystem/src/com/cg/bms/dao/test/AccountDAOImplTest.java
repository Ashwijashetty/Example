package com.cg.bms.dao.test;

import static org.junit.Assert.*;

import java.sql.Date;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.cg.bms.dao.AccountDAOImpl;
import com.cg.bms.exceptions.BMSException;
import com.cg.bms.model.Account;

public class AccountDAOImplTest {

	AccountDAOImpl accountDao=null;
	@Before
	public void setUp() throws Exception {
		
		accountDao=new AccountDAOImpl();
	}

	@After
	public void tearDown() throws Exception {
		accountDao=null;
	}

	@Test
	public void testCreateAccount() {

		Account account=new Account("salaried","shanthi",23000,new java.util.Date(2018,10,13));

		try {
			boolean result=accountDao.createAccount(account);
		 assertEquals(true, result);
		} catch (BMSException e) {
		    e.printStackTrace();
		}
	
	
	}
	@Test
	public void testCreateAccountNull() {

		Account account=new Account("salaried","shanthi",23000,new java.util.Date(2018,10,13));

		try {
			boolean result=accountDao.createAccount(account);
		 assertTrue(true);
		} catch (BMSException e) {
		    e.printStackTrace();
		}
	}
	
	
		@Test
		public void testCreateAccountNull1() {

			Account account=new Account("salaried","shanthi",23000,new java.util.Date(2018,10,13));

			try {
				boolean result=accountDao.createAccount(account);
			 assertFalse(true);
			} catch (BMSException e) {
			    e.printStackTrace();
			}
	}


}
