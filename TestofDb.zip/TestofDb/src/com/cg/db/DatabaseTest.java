package com.cg.db;

import java.sql.Connection;
import java.util.Properties;

public class DatabaseTest {
	
		
	
	    // init database constants
	    private static final String DATABASE_DRIVER = "com.mysql.jdbc.Driver";
	    private static final String DATABASE_URL = "jdbc:mysql://localhost:3306/test";
	    private static final String USERNAME = "root";
	    private static final String PASSWORD = "root";
	    

	    // init connection object
	    private Connection connection;
	    // init properties object
	    private Properties properties;

	    // create properties
	    private Properties getProperties() {
	        if (properties == null) {
	            properties = new Properties();
	            properties.setProperty("user", USERNAME);
	            properties.setProperty("password", PASSWORD);
	            
	        }
	        return properties;
	    }

}
